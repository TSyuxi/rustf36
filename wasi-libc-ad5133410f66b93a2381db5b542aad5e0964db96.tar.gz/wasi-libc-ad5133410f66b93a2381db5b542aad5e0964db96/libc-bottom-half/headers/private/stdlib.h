#define __need_size_t
#define __need_wchar_t
#define __need_NULL
#include <stddef.h>

#include_next <stdlib.h>

int clearenv(void);
