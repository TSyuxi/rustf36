#include <_/cdefs.h>
int snprintf(char *str, size_t size, const char *format, ...);
int rename(const char *oldpath, const char *newpath);
