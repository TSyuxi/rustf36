#ifndef __wasilibc___typedef_in_addr_t_h
#define __wasilibc___typedef_in_addr_t_h

typedef unsigned in_addr_t;

#endif
