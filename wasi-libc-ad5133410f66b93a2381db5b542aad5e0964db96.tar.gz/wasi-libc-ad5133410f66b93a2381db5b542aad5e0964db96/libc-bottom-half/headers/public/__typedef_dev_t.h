#ifndef __wasilibc___typedef_dev_t_h
#define __wasilibc___typedef_dev_t_h

/* Define these as 64-bit integers to support billions of devices. */
typedef unsigned long long dev_t;

#endif
