#ifndef __wasilibc_time_h
#define __wasilibc_time_h

/*
 * Include the real implementation, which is factored into a separate file so
 * that it can be reused by other libc time implementations.
 */
#include <__header_time.h>

#endif
