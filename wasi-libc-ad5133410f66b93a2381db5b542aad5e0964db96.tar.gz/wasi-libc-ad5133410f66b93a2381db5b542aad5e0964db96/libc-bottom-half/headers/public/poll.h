#ifndef __wasilibc_poll_h
#define __wasilibc_poll_h

/*
 * Include the real implementation, which is factored into a separate file so
 * that it can be reused by other libc poll implementations.
 */
#include <__header_poll.h>

#endif
