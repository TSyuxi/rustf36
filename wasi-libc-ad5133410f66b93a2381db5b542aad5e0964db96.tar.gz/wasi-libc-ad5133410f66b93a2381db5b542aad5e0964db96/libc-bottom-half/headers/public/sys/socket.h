#ifndef __wasilibc_sys_socket_h
#define __wasilibc_sys_socket_h

#include <__header_sys_socket.h>

#endif
