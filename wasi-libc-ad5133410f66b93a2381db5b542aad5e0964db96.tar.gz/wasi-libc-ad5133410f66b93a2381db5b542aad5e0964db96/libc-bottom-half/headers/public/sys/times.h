#ifndef __wasilibc_sys_times_h
#define __wasilibc_sys_times_h

#include <__struct_tms.h>

#endif
